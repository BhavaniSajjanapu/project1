# Django-Text-to-HTML-Generator
A simple project to showcase how to convert plain text to html using python django
